/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaprog1a;

import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.json.simple.JSONObject;

/**
 *
 * @author RC_Student_lab
 */
public class myChatApp {
    // List to keep track of all messages that were "sent"
    private ArrayList<Message> sentMessages = new ArrayList<>();
    private int totalSent = 0;
    
    /**
     * //Main method that runs the chat application
     */
   
    
    public void execute() {
      JOptionPane.showMessageDialog(null, "Welcome to My ChatApp");  
            // Main application loop      
            while (true){
                
            // Display menu options to user
             String option = JOptionPane.showInputDialog("""
                                                         Menu:
                                                         1.Send Message
                                                         2."Coming Soon"
                                                         3.Quit
                                                         """);
             // Handle menu option
            if (option.equals("1")){
                
               // Ask how many messages the user wants to send
                int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you wish to enter?"));
                
            //Loop to handle message input multiple times
               for (int i=0; i < count; i++){
                   
                    // Get recipient and message content from user
                   String recipient = JOptionPane.showInputDialog("Enter recipient number(+27616172455)");
                   String content = JOptionPane.showInputDialog("Enter message(max 250 characters)");
                   
                    // Create a new message object
                   Message m = new Message(recipient, content);
                
                   // Validate phone number format
                if (!m.isValidMessageRecipient()){
                    JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain international code.");
                    i--;// Ask again
                    continue;
                }
                // Validate message length
                if (!m.isValidMessageLength()){
                    int over = content.length()-250;
                    JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by" + over + ".Please reduce.");
                    i--;// Ask again
                    continue;
                }
                
                // Ask user what to do with the message
                String action = JOptionPane.showInputDialog("Choose one: Send/Store/Disregard");
                
                // Handle action based on user input
                switch(action.toLowerCase()){
                    case "send": {
                        JOptionPane.showMessageDialog(null, "Message successfully sent");
                        sentMessages.add(m);// Add to sent list
                        totalSent++;// Increase sent count
                        showMessageSummary(m);// Display summary

                    }
                    case "store": {
                        storeToJson(m);// Store message in a file
                        JOptionPane.showMessageDialog(null, "Message stored.");
                        

                    }
                    case "disregard": {
                        JOptionPane.showMessageDialog(null, "Message disregarded. Press 0 to delete");
                        break;
                    }
                    default:{
                        JOptionPane.showMessageDialog(null, "Invalid option.");
                        i--; // Let user re-enter message
                        continue;
                    }
                }
                
               }
            }else if (option.equals("2")){
                // Placeholder for future features
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            }else if (option.equals("3")){
                // Exit the application
                break;
            }else{
                // Invalid input
                JOptionPane.showMessageDialog(null, "Invalid menu option.");
               
            }
        }
        // Final message showing total messages sent during session
        JOptionPane.showMessageDialog(null, "Total messages sent:" + totalSent);
    }
    
    /**
     * Stores a message object into a JSON file (append mode)
     * @param m the message to store
     */
    
    @SuppressWarnings("unchecked")
    private void storeToJson(Message m){
         // Create JSON object with message fields
        JSONObject json = new JSONObject();
        json.put("messageId", m.getMessageId());
        json.put("recipient", m.getRecipient());
        json.put("message", m.getContent());
        json.put("hash", m.getMessageHash());
        
       // Write JSON object to file
      try (FileWriter fw = new FileWriter("store_messages.json",true)){
          fw.write(json.toJSONString() + "\n");
      }catch(Exception e){
          e.printStackTrace();
      }
    }
    
    /**
     * Displays a summary of a sent message
     * @param m the message to summarize
     */
    private void showMessageSummary(Message m){
        JOptionPane.showMessageDialog(null, """
                                            Message Details:
                                            ID:%s
                                            Hash:%s
                                            Recipient:%s
                                            Message:%s
                                            """.formatted(m.getMessageId(), m.createMessageHash(), m.getRecipient(), m.getContent()));
        
    }
 }
    

 

