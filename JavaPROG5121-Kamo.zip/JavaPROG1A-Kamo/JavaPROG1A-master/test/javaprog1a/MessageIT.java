/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaprog1a;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author masho
 */
public class MessageIT {
    
    public MessageIT() {
    }

    @Test
    public void testIsValidMessageRecipient() {
    }

    @Test
    public void testIsValidMessageLength() {
    }

    @Test
    public void testCreateMessageHash() {
    }

    @Test
    public void testGetMessageId() {
    }

    @Test
    public void testGetMessageNumber() {
    }

    @Test
    public void testGetRecipient() {
    }

    @Test
    public void testGetContent() {
    }

    @Test
    public void testGetMessageHash() {
    }
    
}
